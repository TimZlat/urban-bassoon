let page=document.querySelector('.page');
console.log(page);
page.classList.add('dark-theme');